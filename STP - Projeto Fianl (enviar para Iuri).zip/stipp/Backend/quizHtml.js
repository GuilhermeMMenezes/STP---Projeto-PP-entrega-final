const QUESTIONS = [
  {
    id: 1,
    text: "Qual é a principal diferença entre as tags section e div no HTML5?",
    type: "single",
    options: [
      { id: "a", text: "section é usada apenas para imagens, e div apenas para vídeos." },
      { id: "b", text: "section tem valor semântico, enquanto div é genérica.", correct: true },
      { id: "c", text: "div é mais leve e substitui todas as outras tags semânticas." },
      { id: "d", text: "Não há diferença, ambas têm a mesma função." }
    ],
    explanation: "A tag <section> indica uma área temática com significado semântico, útil para SEO e leitores de tela. Já <div> é uma divisão genérica usada apenas para agrupamento visual."
  },
  {
    id: 2,
    text: "Qual das opções diferencia corretamente pseudo-classes e pseudo-elementos em CSS3?",
    type: "single",
    options: [
      { id: "a", text: "Pseudo-classes usam dois-pontos (:) e alteram o estado; pseudo-elementos usam (::) e afetam partes específicas.", correct: true },
      { id: "b", text: "Ambos usam (::) e se aplicam apenas a links." },
      { id: "c", text: "Pseudo-elementos só funcionam em tabelas." },
      { id: "d", text: "Pseudo-classes não existem mais no CSS3." }
    ],
    explanation: "Pseudo-classes controlam estados (:hover, :focus), enquanto pseudo-elementos afetam partes do conteúdo (::before, ::after)."
  },
  {
    id: 3,
    text: "O que compõe o box model em CSS?",
    type: "single",
    options: [
      { id: "a", text: "Margem, borda, espaçamento interno (padding) e conteúdo.", correct: true },
      { id: "b", text: "Apenas o conteúdo e a margem." },
      { id: "c", text: "Somente o padding e o border." },
      { id: "d", text: "Padding, link e cor." }
    ],
    explanation: "O box model define o cálculo de tamanho dos elementos: conteúdo → padding → borda → margem."
  },
  {
    id: 4,
    text: "Qual seletor combinador estiliza o elemento imediatamente após outro?",
    type: "single",
    options: [
      { id: "a", text: "A ~ B" },
      { id: "b", text: "A + B", correct: true },
      { id: "c", text: "A > B" },
      { id: "d", text: "A B" }
    ],
    explanation: "O combinador A + B seleciona o irmão adjacente, ou seja, o elemento que vem logo depois de A."
  },
  {
    id: 5,
    text: "Por que o atributo alt é importante na tag <img>?",
    type: "single",
    options: [
      { id: "a", text: "Ele muda o tamanho da imagem." },
      { id: "b", text: "Define o link de destino da imagem." },
      { id: "c", text: "Descreve a imagem para acessibilidade e mecanismos de busca.", correct: true },
      { id: "d", text: "Define a cor da borda da imagem." }
    ],
    explanation: "O atributo alt fornece uma descrição alternativa da imagem, essencial para acessibilidade e SEO."
  },
  {
    id: 6,
    text: "O que é o Flexbox no CSS?",
    type: "single",
    options: [
      { id: "a", text: "Uma biblioteca externa." },
      { id: "b", text: "Um sistema de layout que facilita o alinhamento e a distribuição de elementos.", correct: true },
      { id: "c", text: "Uma tag HTML." },
      { id: "d", text: "Uma função de JavaScript." }
    ],
    explanation: "O Flexbox é um método moderno de layout que alinha e distribui elementos automaticamente usando propriedades como display: flex e justify-content."
  },
  {
    id: 7,
    text: "Como se faz o link entre um arquivo CSS externo e um HTML?",
    type: "single",
    options: [
      { id: "a", text: "css href='estilo.css'" },
      { id: "b", text: "link rel='stylesheet' href='estilo.css'", correct: true },
      { id: "c", text: "style src='estilo.css'" },
      { id: "d", text: "script rel='stylesheet'" }
    ],
    explanation: "A forma correta é link rel='stylesheet' href='estilo.css'. O CSS externo separa conteúdo de estilo e facilita manutenção."
  },
  {
    id: 8,
    text: "Qual é a função da tag h1 em HTML?",
    type: "single",
    options: [
      { id: "a", text: "Criar um parágrafo." },
      { id: "b", text: "Definir o título principal da página.", correct: true },
      { id: "c", text: "Inserir uma imagem." },
      { id: "d", text: "Fazer uma linha horizontal." }
    ],
    explanation: "A tag h1 representa o título principal e ajuda na hierarquia e SEO do conteúdo."
  },
  {
    id: 9,
    text: "Qual propriedade CSS altera a cor do texto?",
    type: "single",
    options: [
      { id: "a", text: "background-color" },
      { id: "b", text: "text-decoration" },
      { id: "c", text: "color", correct: true },
      { id: "d", text: "font-style" }
    ],
    explanation: "A propriedade color define a cor do texto, enquanto background-color altera o fundo."
  },
  {
    id: 10,
    text: "Qual é o elemento HTML usado para criar parágrafos?",
    type: "single",
    options: [
      { id: "a", text: "p", correct: true },
      { id: "b", text: "h1" },
      { id: "c", text: "div" },
      { id: "d", text: "article" }
    ],
    explanation: "O elemento p define um parágrafo de texto e é um dos blocos básicos do HTML."
  }
];



let current = 0;                   
const answers = {};               
const LS_KEY = "stp_quiz_progress"; 

const elQuestionArea = document.getElementById("questionArea");
const elProgressFill = document.getElementById("progressFill");
const elMetaText = document.getElementById("metaText");
const btnPrev = document.getElementById("btnPrev");
const btnNext = document.getElementById("btnNext");
const btnFinish = document.getElementById("btnFinish");

const resultCard = document.getElementById("result-card");
const quizCard = document.getElementById("quiz-card");
const scoreText = document.getElementById("scoreText");
const feedback = document.getElementById("feedback");

init();

function init(){
  // restaura progresso se existir
  try{
    const saved = JSON.parse(localStorage.getItem(LS_KEY));
    if(saved && saved.answers && saved.current >= 0){
      Object.assign(answers, saved.answers);
      current = Math.min(saved.current, QUESTIONS.length - 1);
    }
  }catch(e){ /* ignore */ }

  render();
  wireEvents();
}

function wireEvents(){
  btnPrev.addEventListener("click", () => { if(current>0){ current--; persist(); render(); } });
  btnNext.addEventListener("click", () => { if(current<QUESTIONS.length-1){ current++; persist(); render(); } });
  btnFinish.addEventListener("click", () => finish());
}

function persist(){
  localStorage.setItem(LS_KEY, JSON.stringify({ current, answers }));
}

// ====== Renderização ======
function render(){
  const q = QUESTIONS[current];
  const total = QUESTIONS.length;
  elMetaText.textContent = `${current + 1}/${total}`;
  elProgressFill.style.width = `${((current + 1) / total) * 100}%`;

  // Monta HTML da pergunta
  elQuestionArea.innerHTML = `
    <div class="question">${q.text}</div>
    <div class="options">
      ${q.options.map(opt => `
        <label class="option" tabindex="0">
          <input type="radio" name="q${q.id}" value="${opt.id}" ${answers[q.id]===opt.id?'checked':''}/>
          <span class="label">${opt.text}</span>
        </label>
      `).join("")}
    </div>
  `;

  // Interações das opções
  elQuestionArea.querySelectorAll('input[type="radio"]').forEach(input=>{
    input.addEventListener("change", (e)=>{
      answers[q.id] = e.target.value;
      persist();
    });
  });
  // Acessibilidade: enter/space para selecionar quando focado no label
  elQuestionArea.querySelectorAll('.option').forEach(lbl=>{
    lbl.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter' || e.key === ' '){
        const input = lbl.querySelector('input'); input.checked = true;
        input.dispatchEvent(new Event('change'));
        e.preventDefault();
      }
    });
  });

  // Navegação: esconder/mostrar botões
  btnPrev.disabled = current === 0;
  btnNext.hidden = current === total - 1;
  btnFinish.hidden = current !== total - 1;
}


function finish(){
  // calcula score
  let correct = 0;
  QUESTIONS.forEach(q=>{
    const chosen = answers[q.id];
    const right = (q.options.find(o=>o.correct) || {}).id;
    if(chosen && chosen === right) correct++;
  });
  const total = QUESTIONS.length;
  const pct = Math.round((correct/total)*100);

  // feedback simples por faixa
  let msg = "";
  if(pct === 100) msg = "Perfeito! Mandou muito! 🚀";
  else if(pct >= 80) msg = "Excelente! Você está voando.";
  else if(pct >= 60) msg = "Bom! Falta pouco para dominar.";
  else msg = "Bora revisar e tentar de novo 😉";

  scoreText.textContent = `Você acertou ${correct} de ${total} (${pct}%).`;
  feedback.innerHTML = `
    <p>${msg}</p>
    <details>
      <summary>Ver explicações</summary>
      <ol>
        ${QUESTIONS.map(q=>{
          const right = q.options.find(o=>o.correct);
          const chosen = q.options.find(o=>o.id === answers[q.id]);
          const ok = chosen && right && chosen.id === right.id;
          return `
            <li style="margin-bottom:10px;">
              <strong>${q.text}</strong><br/>
              Sua resposta: ${chosen?chosen.text:"(não respondida)"} ${ok? "✅" : "❌"}<br/>
              Correta: ${right?right.text:"—"}<br/>
              <em>${q.explanation || ""}</em>
            </li>
          `;
        }).join("")}
      </ol>
    </details>
  `;

  quizCard.hidden = true;
  resultCard.hidden = false;

  document.getElementById("btnRetry").onclick = () => {
    Object.keys(answers).forEach(k=> delete answers[k]);
    current = 0;
    persist();
    resultCard.hidden = true;
    quizCard.hidden = false;
    render();
  };
}
