const QUESTIONS = [
  {
    id: 1,
    text: "O que é uma variável em Python e como se declara?",
    type: "single",
    options: [
      { id: "a", text: "Uma função que retorna um valor aleatório." },
      { id: "b", text: "Um espaço na memória que armazena um valor.", correct: true },
      { id: "c", text: "Uma tag HTML usada para exibir texto no navegador." },
      { id: "d", text: "Uma palavra reservada usada para importar módulos." }
    ],
    explanation: "Em Python, uma variável guarda dados (números, textos, booleanos) para serem usados depois no programa."
  },
  {
    id: 2,
    text: "Qual é a diferença entre os tipos de dados `int`, `float` e `str` em Python?",
    type: "single",
    options: [
      { id: "a", text: "`int` é para texto, `float` para números inteiros, `str` para verdadeiros/falsos." },
      { id: "b", text: "`int` representa inteiros, `float` representa números com casa decimal, `str` representa sequências de caracteres.", correct: true },
      { id: "c", text: "`int` e `float` são o mesmo tipo, `str` é para listas." },
      { id: "d", text: "`str` é para números, `int` para texto, `float` para booleanos." }
    ],
    explanation: "`int` = inteiros (ex: 5), `float` = decimais (ex: 3.14), `str` = texto (ex: \"Olá\")."
  },
  {
    id: 3,
    text: "Como se utiliza a estrutura condicional `if` em Python?",
    type: "single",
    options: [
      { id: "a", text: "if (condição) { … } else { … }" },
      { id: "b", text: "if condição: … elif outra_condição: … else: …", correct: true },
      { id: "c", text: "switch condição: … case …" },
      { id: "d", text: "condição ? valor1 : valor2" }
    ],
    explanation: "Em Python usa-se `if condição:` seguido de indentação; para outros casos `elif` e `else`."
  },
  {
    id: 4,
    text: "O que é um laço (loop) `for` em Python e para que serve?",
    type: "single",
    options: [
      { id: "a", text: "Serve para definir uma função." },
      { id: "b", text: "Serve para repetir um bloco de código um número definido de vezes.", correct: true },
      { id: "c", text: "Serve para importar módulos externos." },
      { id: "d", text: "Serve para parar a execução do programa." }
    ],
    explanation: "O `for` percorre sequências (listas, strings, range) repetindo o bloco para cada item."
  },
  {
    id: 5,
    text: "Qual das alternativas mostra corretamente uma função em Python que recebe dois parâmetros e retorna a soma?",
    type: "single",
    options: [
      { id: "a", text: "def soma(a, b): return a + b", correct: true },
      { id: "b", text: "function soma(a, b) { return a + b }" },
      { id: "c", text: "fun soma(a, b): a + b = return" },
      { id: "d", text: "def soma(a, b): print(a + b)" }
    ],
    explanation: "Em Python usa-se `def nome(parâmetros): return valor`. A alternativa (a) está correta."
  },
  {
    id: 6,
    text: "Para que serve a função `input()` em Python?",
    type: "single",
    options: [
      { id: "a", text: "Para adicionar um item a uma lista." },
      { id: "b", text: "Para pausar o programa por um tempo." },
      { id: "c", text: "Para receber dados digitados pelo usuário.", correct: true },
      { id: "d", text: "Para converter texto em número." }
    ],
    explanation: "`input()` lê uma entrada do usuário como string. Depois pode-se converter para outro tipo."
  },
  {
    id: 7,
    text: "Qual destas sentenças converte corretamente uma string para número inteiro em Python?",
    type: "single",
    options: [
      { id: "a", text: "int('123')", correct: true },
      { id: "b", text: "str(123)" },
      { id: "c", text: "float('123')" },
      { id: "d", text: "boolean('123')" }
    ],
    explanation: "Usa-se `int('123')` para converter string em inteiro. `float('123')` daria decimal, etc."
  },
  {
    id: 8,
    text: "Em Python, o que faz o operador `==`?",
    type: "single",
    options: [
      { id: "a", text: "Atribui um valor a uma variável." },
      { id: "b", text: "Compara se dois valores são iguais.", correct: true },
      { id: "c", text: "Verifica se um valor é maior que outro." },
      { id: "d", text: "Negaciona o valor booleano." }
    ],
    explanation: "`==` compara igualdade entre valores. Atribuição usa `=`."
  },
  {
    id: 9,
    text: "Qual é o resultado da expressão `len('curso')` em Python?",
    type: "single",
    options: [
      { id: "a", text: "4" },
      { id: "b", text: "5", correct: true },
      { id: "c", text: "6" },
      { id: "d", text: "Erro" }
    ],
    explanation: "`len('curso')` retorna o número de caracteres na string, que são 5."
  },
  {
    id: 10,
    text: "Em Python, qual palavra-chave usamos para tratar exceções (erros) de execução?",
    type: "single",
    options: [
      { id: "a", text: "try/except", correct: true },
      { id: "b", text: "catch/throw" },
      { id: "c", text: "error/handle" },
      { id: "d", text: "if/else" }
    ],
    explanation: "Usa-se `try:` e `except:` para capturar exceções em Python."
  }
];



let current = 0;                   
const answers = {};               
const LS_KEY = "stp_quiz_progress"; 

const elQuestionArea = document.getElementById("questionArea");
const elProgressFill = document.getElementById("progressFill");
const elMetaText = document.getElementById("metaText");
const btnPrev = document.getElementById("btnPrev");
const btnNext = document.getElementById("btnNext");
const btnFinish = document.getElementById("btnFinish");

const resultCard = document.getElementById("result-card");
const quizCard = document.getElementById("quiz-card");
const scoreText = document.getElementById("scoreText");
const feedback = document.getElementById("feedback");

init();

function init(){
  // restaura progresso se existir
  try{
    const saved = JSON.parse(localStorage.getItem(LS_KEY));
    if(saved && saved.answers && saved.current >= 0){
      Object.assign(answers, saved.answers);
      current = Math.min(saved.current, QUESTIONS.length - 1);
    }
  }catch(e){ /* ignore */ }

  render();
  wireEvents();
}

function wireEvents(){
  btnPrev.addEventListener("click", () => { if(current>0){ current--; persist(); render(); } });
  btnNext.addEventListener("click", () => { if(current<QUESTIONS.length-1){ current++; persist(); render(); } });
  btnFinish.addEventListener("click", () => finish());
}

function persist(){
  localStorage.setItem(LS_KEY, JSON.stringify({ current, answers }));
}

// ====== Renderização ======
function render(){
  const q = QUESTIONS[current];
  const total = QUESTIONS.length;
  elMetaText.textContent = `${current + 1}/${total}`;
  elProgressFill.style.width = `${((current + 1) / total) * 100}%`;

  // Monta HTML da pergunta
  elQuestionArea.innerHTML = `
    <div class="question">${q.text}</div>
    <div class="options">
      ${q.options.map(opt => `
        <label class="option" tabindex="0">
          <input type="radio" name="q${q.id}" value="${opt.id}" ${answers[q.id]===opt.id?'checked':''}/>
          <span class="label">${opt.text}</span>
        </label>
      `).join("")}
    </div>
  `;

  // Interações das opções
  elQuestionArea.querySelectorAll('input[type="radio"]').forEach(input=>{
    input.addEventListener("change", (e)=>{
      answers[q.id] = e.target.value;
      persist();
    });
  });
  // Acessibilidade: enter/space para selecionar quando focado no label
  elQuestionArea.querySelectorAll('.option').forEach(lbl=>{
    lbl.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter' || e.key === ' '){
        const input = lbl.querySelector('input'); input.checked = true;
        input.dispatchEvent(new Event('change'));
        e.preventDefault();
      }
    });
  });

  // Navegação: esconder/mostrar botões
  btnPrev.disabled = current === 0;
  btnNext.hidden = current === total - 1;
  btnFinish.hidden = current !== total - 1;
}


function finish(){
  // calcula score
  let correct = 0;
  QUESTIONS.forEach(q=>{
    const chosen = answers[q.id];
    const right = (q.options.find(o=>o.correct) || {}).id;
    if(chosen && chosen === right) correct++;
  });
  const total = QUESTIONS.length;
  const pct = Math.round((correct/total)*100);

  // feedback simples por faixa
  let msg = "";
  if(pct === 100) msg = "Perfeito! Mandou muito! 🚀";
  else if(pct >= 80) msg = "Excelente! Você está voando.";
  else if(pct >= 60) msg = "Bom! Falta pouco para dominar.";
  else msg = "Bora revisar e tentar de novo 😉";

  scoreText.textContent = `Você acertou ${correct} de ${total} (${pct}%).`;
  feedback.innerHTML = `
    <p>${msg}</p>
    <details>
      <summary>Ver explicações</summary>
      <ol>
        ${QUESTIONS.map(q=>{
          const right = q.options.find(o=>o.correct);
          const chosen = q.options.find(o=>o.id === answers[q.id]);
          const ok = chosen && right && chosen.id === right.id;
          return `
            <li style="margin-bottom:10px;">
              <strong>${q.text}</strong><br/>
              Sua resposta: ${chosen?chosen.text:"(não respondida)"} ${ok? "✅" : "❌"}<br/>
              Correta: ${right?right.text:"—"}<br/>
              <em>${q.explanation || ""}</em>
            </li>
          `;
        }).join("")}
      </ol>
    </details>
  `;

  quizCard.hidden = true;
  resultCard.hidden = false;

  document.getElementById("btnRetry").onclick = () => {
    Object.keys(answers).forEach(k=> delete answers[k]);
    current = 0;
    persist();
    resultCard.hidden = true;
    quizCard.hidden = false;
    render();
  };
}
