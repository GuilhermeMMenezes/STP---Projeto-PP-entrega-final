async function cadastrar() {

    const nomeUsuario = document.getElementById('nomeUsuario').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value

    if (!nomeUsuario || !email || !senha) {
      alert('Preencha todos os campos!');
      return;
  }

    const response = await fetch('http://localhost:3002/cadastrar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nomeUsuario, email , senha})
    });

    const result = await response.json();

    if (result.success) {
      alert("cadastro bem-sucedido!");
      window.location.href = "login.html";
    } else {
      alert("Usuário ou senha incorretos!");
    }

};

document.getElementById('cadastrar').addEventListener('click', cadastrar);