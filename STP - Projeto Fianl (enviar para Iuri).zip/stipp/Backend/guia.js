
    const LINKS = {
      htmlcss: {
        curso: 'paginahtml.html',     
        atividades: 'paginahtml.html',
        jogos: 'paginahtml.html'
      },
      js: {
        curso: 'paginajavascript.html',
        atividades: 'paginajavascript.html',
        jogos: 'paginajavascript.html'
      },
      python: {
        curso: 'paginapython.html',
        atividades: 'paginapython.html',
        jogos: 'paginapython.html'
      }
    };

    function trilhaHTMLCSS(){
      return {
        titulo: 'Trilha 1 — HTML & CSS',
        passos: [
          {titulo:'Cursos', texto:'Estrutura, semântica, layout, responsividade, flex/grid e boas práticas.',
           link: LINKS.htmlcss.curso, linkText:'Abrir curso HTML & CSS'},
          {titulo:'Atividades', texto:'Mini-projetos: landing, card, navbar, grid de produtos.',
           link: LINKS.htmlcss.atividades, linkText:'Ver atividades'},
          {titulo:'Jogos', texto:'Flexbox Froggy, Grid Garden e desafios visuais.',
           link: LINKS.htmlcss.jogos, linkText:'Jogar e fixar'}
        ]
      };
    }
    function trilhaJS(){
      return {
        titulo: 'Trilha 2 — JavaScript',
        passos: [
          {titulo:'Cursos', texto:'Fundamentos, DOM, eventos, módulos, fetch, lógica.',
           link: LINKS.js.curso, linkText:'Abrir curso JavaScript'},
          {titulo:'Atividades', texto:'To-do list, modal, quiz, consumo de API.',
           link: LINKS.js.atividades, linkText:'Ver atividades'},
          {titulo:'Jogos', texto:'Code Combat / desafios de lógica.',
           link: LINKS.js.jogos, linkText:'Jogar e fixar'}
        ]
      };
    }
    function trilhaPython(){
      return {
        titulo: 'Trilha 3 — Python (IA/Automação)',
        passos: [
          {titulo:'Cursos', texto:'Sintaxe, libs básicas, dados e introdução à IA.',
           link: LINKS.python.curso, linkText:'Abrir curso Python'},
          {titulo:'Atividades', texto:'Scripts de automação, análise simples de dados.',
           link: LINKS.python.atividades, linkText:'Ver atividades'},
          {titulo:'Jogos', texto:'Katas de lógica e desafios.',
           link: LINKS.python.jogos, linkText:'Jogar e fixar'}
        ]
      };
    }

 
    function recomendar({objetivo, nivel, preferencia}){
      let trilhas = [];

      if (objetivo === 'estilizacao') {
        trilhas = [trilhaHTMLCSS(), trilhaJS(), trilhaPython()];
      } else if (objetivo === 'web_basico') {
        trilhas = [trilhaHTMLCSS(), trilhaJS(), trilhaPython()];
      } else if (objetivo === 'logica_js') {
        trilhas = [trilhaJS(), trilhaHTMLCSS(), trilhaPython()];
      } else if (objetivo === 'ia_python') {
        trilhas = [trilhaPython(), trilhaJS(), trilhaHTMLCSS()];
      }

  
      if (nivel === 'iniciante' && trilhas[0].titulo.includes('JavaScript')) {
   
        trilhas = [trilhaHTMLCSS(), trilhas[0], trilhas[2] ?? trilhaPython()];
      }
      if (preferencia === 'pratico') {
     
        trilhas = trilhas.map(t => ({
          ...t,
          passos: [t.passos[1], t.passos[2], t.passos[0]]
        }));
      }
      return trilhas;
    }


    function renderPlano(trilhas){
      const container = document.getElementById('plano');
      container.innerHTML = '';
      trilhas.forEach(t => {
        const sec = document.createElement('div');
        sec.className = 'step';
        sec.innerHTML = `
          <h4>${t.titulo}</h4>
          <div class="content">
            <div class="cols">
              ${t.passos.map(p => `
                <div class="mini">
                  <h5>${p.titulo}</h5>
                  <p>${p.texto}</p>
                  <a href="${p.link}" target="_self">${p.linkText}</a>
                </div>
              `).join('')}
            </div>
          </div>
        `;
        container.appendChild(sec);
      });
    }

  
    document.getElementById('wizard').addEventListener('submit', (e)=>{
      e.preventDefault();
      const objetivo = document.getElementById('objetivo').value;
      const nivel = (new FormData(e.target)).get('nivel');
      const preferencia = (new FormData(e.target)).get('preferencia');

      if(!objetivo) return;

      const trilhas = recomendar({objetivo, nivel, preferencia});
      document.getElementById('resultado').hidden = false;

      const labelObj = {
        estilizacao:'focar em estilização/front',
        web_basico:'começar do zero em Web',
        logica_js:'focar em lógica e JS',
        ia_python:'seguir para IA/automação com Python'
      }[objetivo];

      document.getElementById('resumo').textContent =
        `Plano sugerido para ${labelObj}. Ordem pensada para acelerar seu aprendizado, considerando nível “${nivel}” e estilo “${preferencia}”.`;
      renderPlano(trilhas);
 
      document.getElementById('resultado').scrollIntoView({behavior:'smooth', block:'start'});
    });
