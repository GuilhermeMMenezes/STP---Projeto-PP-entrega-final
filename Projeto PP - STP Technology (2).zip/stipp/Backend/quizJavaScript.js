const QUESTIONS = [
  {
    id: 1,
    text: "O que é uma função em JavaScriptO que é o JavaScript e para que ele serve em uma página web?",
    type: "single",
    options: [
      { id: "a", text: "É uma linguagem de programação que adiciona interatividade e dinamismo às páginas.", correct: true },
      { id: "b", text: "É uma linguagem usada apenas para estilizar o site." },
      { id: "c", text: "É uma linguagem de marcação para estruturar o conteúdo." },
      { id: "d", text: "É um banco de dados usado dentro do navegador." }
    ],
    explanation: "avaScript é uma linguagem de programação usada para criar interatividade (como animações, botões clicáveis, validação de formulários, etc.) HTML define o conteúdo e CSS cuida do estilo — o JavaScript traz vida ao site."
  },
  {
    id: 2,
    text: "O que é uma variável e como se declara uma em JavaScript?",
    type: "single",
    options: [
      { id: "a", text: "É uma função que retorna um valor aleatório." },
      { id: "b", text: "É um espaço na memória que armazena um valor.", correct: true },
      { id: "c", text: "É uma tag usada para exibir texto no navegador." },
      { id: "d", text: "É uma palavra reservada usada para importar bibliotecas." }
    ],
    explanation: "Variáveis guardam informações (como números, textos ou booleanos) que o programa usa depois."
  },
  {
    id: 3,
    text: "O que é uma função em JavaScript e por que ela é útil?",
    type: "single",
    options: [
      { id: "a", text: "É um tipo de variável que guarda um número." },
      { id: "b", text: "É um bloco de código reutilizável que executa uma tarefa específica.", correct: true },
      { id: "c", text: "É um comando que apaga dados do navegador." },
      { id: "d", text: "É uma estrutura condicional usada para comparar valores." }
    ],
    explanation: "funções são blocos de código que podem ser chamados várias vezes — evitando repetição."
  },
  {
    id: 4,
    text: "Qual das alternativas define corretamente uma arrow function??",
    type: "single",
    options: [
      { id: "a", text: "Uma função que possui seu próprio this" },
      { id: "b", text: "Uma função usada apenas dentro de classes." },
      { id: "c", text: "Uma função mais curta que não cria seu próprio this e tem sintaxe simplificada.", correct: true },
      { id: "d", text: "Um tipo de loop em ES6." }
    ],
    explanation: "Arrow functions não criam seu próprio this, herdando do contexto externo."
  },
  {
    id: 5,
    text: "Quando é mais indicado usar o switch em vez de vários if/else?",
    type: "single",
    options: [
      { id: "a", text: "Quando há apenas uma condição." },
      { id: "b", text: "Quando queremos comparar valores booleanos." },
      { id: "c", text: "Quando há muitas comparações com o mesmo valor.", correct: true },
      { id: "d", text: "Nunca, o switch é obsoleto." }
    ],
    explanation: "switch é ideal quando você precisa testar uma mesma variável contra vários valores — deixando o código mais limpo e rápido."
  },
  {
    id: 6,
    text: "O que é hoisting em JavaScript?",
    type: "single",
    options: [
      { id: "a", text: "É o método de empilhar funções na call stack." },
      { id: "b", text: "É o processo de limpar a memória após o uso de uma variável." },
      { id: "c", text: "É a capacidade de uma função ser chamada antes de ser declarada.", correct: true },
      { id: "d", text: "É o nome dado ao carregamento assíncrono do código." }
    ],
    explanation: "O hoisting faz com que declarações (de variáveis e funções) sejam movidas para o topo do escopo antes da execução."
  },
  {
    id: 7,
    text: "Qual das opções explica melhor a diferença entre var, let e const?",
    type: "single",
    options: [
      { id: "a", text: "Const permite reatribuição de valores, enquanto let não." },
      { id: "b", text: "Todas se comportam exatamente da mesma forma." },
      { id: "c", text: "let e const têm escopo de bloco, enquanto var tem escopo de função.", correct: true },
      { id: "d", text: "Var tem escopo de bloco, enquanto let e const têm escopo global." }
    ],
    explanation: "O hoisting faz com que declarações (de variáveis e funções) sejam movidas para o topo do escopo antes da execução."
  },
  {
    id: 8,
    text: "O que é o Event Loop em JavaScript?",
    type: "single",
    options: [
      { id: "a", text: "Um mecanismo que executa funções de forma síncrona e sequencial." },
      { id: "b", text: "Um tipo especial de loop usado para percorrer arrays." },
      { id: "c", text: "Um processo que garante que o código assíncrono seja executado após o call stack estar vazio.", correct: true },
      { id: "d", text: "Uma API que cria eventos de interface." }
    ],
    explanation: "O Event Loop gerencia a execução assíncrona do JavaScript, verificando a call stack e as filas de callbacks e promises."
  },
  {
    id: 9,
    text: "O que são closures em JavaScript?",
    type: "single",
    options: [
      { id: "a", text: "Funções que se autoexecutam e apagam variáveis após o uso." },
      { id: "b", text: "Funções que armazenam o estado de variáveis externas ao seu escopo.", correct: true },
      { id: "c", text: "Funções que só podem ser executadas uma vez." },
      { id: "d", text: "Funções que fecham o navegador quando ocorrem erros." }
    ],
    explanation: "Closures permitem que funções internas acessem variáveis externas mesmo após o escopo pai ter sido finalizado."
  }
];


let current = 0;                   
const answers = {};               
const LS_KEY = "stp_quiz_progress"; 

const elQuestionArea = document.getElementById("questionArea");
const elProgressFill = document.getElementById("progressFill");
const elMetaText = document.getElementById("metaText");
const btnPrev = document.getElementById("btnPrev");
const btnNext = document.getElementById("btnNext");
const btnFinish = document.getElementById("btnFinish");

const resultCard = document.getElementById("result-card");
const quizCard = document.getElementById("quiz-card");
const scoreText = document.getElementById("scoreText");
const feedback = document.getElementById("feedback");

init();

function init(){
  // restaura progresso se existir
  try{
    const saved = JSON.parse(localStorage.getItem(LS_KEY));
    if(saved && saved.answers && saved.current >= 0){
      Object.assign(answers, saved.answers);
      current = Math.min(saved.current, QUESTIONS.length - 1);
    }
  }catch(e){ /* ignore */ }

  render();
  wireEvents();
}

function wireEvents(){
  btnPrev.addEventListener("click", () => { if(current>0){ current--; persist(); render(); } });
  btnNext.addEventListener("click", () => { if(current<QUESTIONS.length-1){ current++; persist(); render(); } });
  btnFinish.addEventListener("click", () => finish());
}

function persist(){
  localStorage.setItem(LS_KEY, JSON.stringify({ current, answers }));
}

// ====== Renderização ======
function render(){
  const q = QUESTIONS[current];
  const total = QUESTIONS.length;
  elMetaText.textContent = `${current + 1}/${total}`;
  elProgressFill.style.width = `${((current + 1) / total) * 100}%`;

  // Monta HTML da pergunta
  elQuestionArea.innerHTML = `
    <div class="question">${q.text}</div>
    <div class="options">
      ${q.options.map(opt => `
        <label class="option" tabindex="0">
          <input type="radio" name="q${q.id}" value="${opt.id}" ${answers[q.id]===opt.id?'checked':''}/>
          <span class="label">${opt.text}</span>
        </label>
      `).join("")}
    </div>
  `;

  // Interações das opções
  elQuestionArea.querySelectorAll('input[type="radio"]').forEach(input=>{
    input.addEventListener("change", (e)=>{
      answers[q.id] = e.target.value;
      persist();
    });
  });
  // Acessibilidade: enter/space para selecionar quando focado no label
  elQuestionArea.querySelectorAll('.option').forEach(lbl=>{
    lbl.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter' || e.key === ' '){
        const input = lbl.querySelector('input'); input.checked = true;
        input.dispatchEvent(new Event('change'));
        e.preventDefault();
      }
    });
  });

  // Navegação: esconder/mostrar botões
  btnPrev.disabled = current === 0;
  btnNext.hidden = current === total - 1;
  btnFinish.hidden = current !== total - 1;
}


function finish(){
  // calcula score
  let correct = 0;
  QUESTIONS.forEach(q=>{
    const chosen = answers[q.id];
    const right = (q.options.find(o=>o.correct) || {}).id;
    if(chosen && chosen === right) correct++;
  });
  const total = QUESTIONS.length;
  const pct = Math.round((correct/total)*100);

  // feedback simples por faixa
  let msg = "";
  if(pct === 100) msg = "Perfeito! Mandou muito! 🚀";
  else if(pct >= 80) msg = "Excelente! Você está voando.";
  else if(pct >= 60) msg = "Bom! Falta pouco para dominar.";
  else msg = "Bora revisar e tentar de novo 😉";

  scoreText.textContent = `Você acertou ${correct} de ${total} (${pct}%).`;
  feedback.innerHTML = `
    <p>${msg}</p>
    <details>
      <summary>Ver explicações</summary>
      <ol>
        ${QUESTIONS.map(q=>{
          const right = q.options.find(o=>o.correct);
          const chosen = q.options.find(o=>o.id === answers[q.id]);
          const ok = chosen && right && chosen.id === right.id;
          return `
            <li style="margin-bottom:10px;">
              <strong>${q.text}</strong><br/>
              Sua resposta: ${chosen?chosen.text:"(não respondida)"} ${ok? "✅" : "❌"}<br/>
              Correta: ${right?right.text:"—"}<br/>
              <em>${q.explanation || ""}</em>
            </li>
          `;
        }).join("")}
      </ol>
    </details>
  `;

  quizCard.hidden = true;
  resultCard.hidden = false;

  document.getElementById("btnRetry").onclick = () => {
    Object.keys(answers).forEach(k=> delete answers[k]);
    current = 0;
    persist();
    resultCard.hidden = true;
    quizCard.hidden = false;
    render();
  };
}
