async function carregarPerfil() {
  const userEmail = localStorage.getItem("userEmail");

  if (!userEmail) {
    alert("Você precisa estar logado!");
    window.location.href = "login.html";
    return;
  }

  try {
    const response = await fetch(`http://localhost:3002/perfil/${userEmail}`);
    const result = await response.json();

    if (!result.success) {
      alert("Erro ao carregar seu perfil");
      return;
    }

    document.getElementById("nome").value = result.data.nomeUsuario;
    document.getElementById("email").value = result.data.email;

  } catch (err) {
    console.error(err);
    alert("Falha ao carregar dados do perfil.");
  }
}

document.addEventListener("DOMContentLoaded", carregarPerfil);


async function deletarConta() {
  const userEmail = localStorage.getItem("userEmail");

  const confirmar = confirm("Tem certeza que deseja excluir sua conta? Isso não poderá ser desfeito.");

  if (!confirmar) return;

  try {
    const response = await fetch(`http://localhost:3002/usuario/${userEmail}`, {
      method: "DELETE"
    });

    const result = await response.json();

    if (result.success) {
      alert("Conta excluída com sucesso!");

      // limpar dados locais
      localStorage.removeItem("userEmail");

      // redirecionar
      window.location.href = "cadastro.html";
    } else {
      alert("Erro: " + result.message);
    }

  } catch (err) {
    console.error(err);
    alert("Falha ao excluir a conta.");
  }
}

document.getElementById("deletar").addEventListener("click", deletarConta);




// Carrega dados do usuário logado
async function carregarPerfil() {
  const userEmail = localStorage.getItem("userEmail");

  if (!userEmail) {
    alert("Você precisa estar logado para acessar o perfil.");
    window.location.href = "login.html";
    return;
  }

  try {
    const response = await fetch(`http://localhost:3002/perfil/${userEmail}`);
    const result = await response.json();

    if (!result.success) {
      alert(result.message || "Erro ao carregar seu perfil.");
      return;
    }

    const user = result.data;
    document.getElementById("nome").value = user.nomeUsuario;
    document.getElementById("email").value = user.email;

  } catch (err) {
    console.error(err);
    alert("Falha ao carregar dados do perfil.");
  }
}

// Habilitar edição
function habilitarEdicao() {
  document.getElementById("nome").disabled = false;
  document.getElementById("email").disabled = false;

  document.getElementById("editar").hidden = true;
  document.getElementById("salvar").hidden = false;
}

// Salvar alterações no backend
async function salvarPerfil(event) {
  event.preventDefault();

  const nome = document.getElementById("nome").value.trim();
  const emailNovo = document.getElementById("email").value.trim();
  const emailAtual = localStorage.getItem("userEmail");

  if (!nome || !emailNovo) {
    alert("Preencha nome e e-mail.");
    return;
  }

  try {
    const response = await fetch(`http://localhost:3002/usuario/${emailAtual}`, {
      method: "PUT",
      headers: { "Content-Type":"application/json" },
      body: JSON.stringify({ nomeUsuario: nome, emailNovo })
    });

    const result = await response.json();

    if (!response.ok || !result.success) {
      alert(result.message || "Erro ao salvar alterações.");
      return;
    }

    // Atualiza email no localStorage se mudou
    localStorage.setItem("userEmail", emailNovo);

    // Volta os campos para modo de visualização
    document.getElementById("nome").disabled = true;
    document.getElementById("email").disabled = true;
    document.getElementById("editar").hidden = false;
    document.getElementById("salvar").hidden = true;

    alert("Perfil atualizado com sucesso!");

  } catch (err) {
    console.error(err);
    alert("Falha ao atualizar perfil.");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  carregarPerfil();

  const btnEditar = document.getElementById("editar");
  const btnSalvar = document.getElementById("salvar");
  const btnDeletar = document.getElementById("deletar");
  const form = document.getElementById("perfilForm");

  if (btnEditar) btnEditar.addEventListener("click", habilitarEdicao);
  if (form) form.addEventListener("submit", salvarPerfil);
  if (btnDeletar) btnDeletar.addEventListener("click", deletarConta);
});
