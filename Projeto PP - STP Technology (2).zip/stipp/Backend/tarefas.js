const API = 'http://localhost:3002';

async function loadTarefas() {
  try {
    const resp = await fetch(`${API}/tarefas`);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const json = await resp.json();
    const lista = document.getElementById('listaTarefas');

    if (!json.success || !json.data || json.data.length === 0) {
      lista.innerHTML = '<li>Nenhuma tarefa cadastrada.</li>';
      return;
    }

    lista.innerHTML = json.data.map(t => `
      <li>
        <strong>${escapeHTML(t.nomeTarefa)}</strong><br>
        <small>${escapeHTML(t.descricao)}</small>
        ${t.created_at ? `<div style="opacity:.7;font-size:12px;">${formatDate(t.created_at)}</div>` : ''}
      </li>
    `).join('');
  } catch (e) {
    console.error(e);
    document.getElementById('listaTarefas').innerHTML =
      '<li style="color:#b00">Erro ao carregar tarefas.</li>';
  }
}

async function cadastrar() {
  const nomeTarefa = document.getElementById('nomeTarefa').value.trim();
  const descricao  = document.getElementById('descricao').value.trim();

  if (!nomeTarefa || !descricao) {
    alert('Preencha todos os campos!');
    return;
  }

  try {
    const response = await fetch(`${API}/tarefas`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nomeTarefa, descricao })
    });

    if (!response.ok) throw new Error(`HTTP ${response.status} - ${await response.text()}`);
    const result = await response.json();

    if (result.success) {
      // limpa e recarrega a lista
      document.getElementById('nomeTarefa').value = '';
      document.getElementById('descricao').value = '';
      await loadTarefas();
    } else {
      alert(result.message || 'Não conseguiu cadastrar a tarefa');
    }
  } catch (err) {
    console.error(err);
    alert('Falha ao cadastrar tarefa.');
  }
}


function escapeHTML(str = '') {
  return str.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
function formatDate(iso) {
  const d = new Date(iso);
  return isNaN(d) ? '' : d.toLocaleString();
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('tarefa')?.addEventListener('click', cadastrar);
  loadTarefas();
});

