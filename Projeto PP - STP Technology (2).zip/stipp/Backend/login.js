async function login() {
  const email = document.getElementById('email').value;
  const senha = document.getElementById('senha').value;

  if (!email || !senha) {
    alert('Preencha todos os campos!');
    return;
  }

  try {
const response = await fetch('http://localhost:3002/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, senha })
});






    
    if (!response.ok) {
      const txt = await response.text();
      throw new Error(`Erro ${response.status}: ${txt}`);
    }

    const result = await response.json();

  
    if (result.success) {
      localStorage.setItem("userEmail", email);
      alert('Login bem-sucedido!');
      window.location.href = 'index.html';
    } else {
      alert(result.message || 'Usuário ou senha incorretos!');
    }
  } catch (err) {
    console.error(err);
    alert('Falha ao conectar. Tente novamente.');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('login');
  if (btn) btn.addEventListener('click', login);
});


