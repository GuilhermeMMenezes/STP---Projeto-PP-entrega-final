create database sti;
use sti;

create table usuario(
id int auto_increment unique,
nomeUsuario varchar(255) not null,
email varchar(255) unique not null primary key,
senha varchar(255) not null
);

create table tarefas(
 id INT AUTO_INCREMENT PRIMARY KEY,
nomeTarefa varchar(255) not null,
descricao varchar(255) not null,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
drop table tarefas;

create table ponto(
email_usuario varchar(255),
ponto int,

foreign key (email_usuario) references usuario(email)
);

select * from usuario;
select * from tarefas;
